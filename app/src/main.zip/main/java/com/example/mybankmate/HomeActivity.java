package com.example.mybankmate;public class HomeActivity {
}
