package com.example.mybankmate;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomeActivity extends AppCompatActivity {
    private TextView accountDetailsTextView;
    private DatabaseReference usersDatabaseRef;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        accountDetailsTextView = findViewById(R.id.accountDetailsTextView);
        firebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = firebaseAuth.getCurrentUser();

        if (currentUser != null) {
            usersDatabaseRef = FirebaseDatabase.getInstance().getReference("Users").child(currentUser.getUid());
            loadUserAccountDetails();
        }
    }

    private void loadUserAccountDetails() {
        usersDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String email = dataSnapshot.getValue(String.class);
                accountDetailsTextView.setText("Account Details: \nEmail: " + email);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                accountDetailsTextView.setText("Failed to load account details.");
            }
        });
    }
}
